
<!DOCTYPE html>
<html>
<head>
    <title>GLPI - Dashboard - Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <meta http-equiv="Pragma" content="public">
    <meta http-equiv="refresh" content="0; url=assets.php" />        
      	 
</head>
<body style='background-color: #FFF;'>
</body>
</html>